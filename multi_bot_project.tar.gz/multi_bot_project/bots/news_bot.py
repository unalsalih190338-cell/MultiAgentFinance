import telebot

def build_bot(token):
    bot = telebot.TeleBot(token, threaded=False)

    @bot.message_handler(commands=["start", "help"])
    def start(message):
        bot.reply_to(message, "News Bot aktif. Komutlar: /ping /news")

    @bot.message_handler(commands=["ping"])
    def ping(message):
        bot.reply_to(message, "news pong")

    @bot.message_handler(commands=["news"])
    def news(message):
        bot.reply_to(message, "News altyapisi aktif, kaynaklar sonraki adimda eklenecek.")

    return bot
