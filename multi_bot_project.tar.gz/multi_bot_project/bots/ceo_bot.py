import telebot

def build_bot(token):
    bot = telebot.TeleBot(token, threaded=False)

    @bot.message_handler(commands=["start", "help"])
    def start(message):
        bot.reply_to(message, "CEO Bot aktif. Komutlar: /ping /status")

    @bot.message_handler(commands=["ping"])
    def ping(message):
        bot.reply_to(message, "ceo pong")

    @bot.message_handler(commands=["status"])
    def status(message):
        bot.reply_to(message, "CEO panel altyapisi aktif. Diger bot raporlari sonraki adimda baglanacak.")

    return bot
