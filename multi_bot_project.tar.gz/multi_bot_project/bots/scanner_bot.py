import telebot

def build_bot(token):
    bot = telebot.TeleBot(token, threaded=False)

    @bot.message_handler(commands=["start", "help"])
    def start(message):
        bot.reply_to(message, "Scanner Bot aktif. Komutlar: /ping /scan THYAO")

    @bot.message_handler(commands=["ping"])
    def ping(message):
        bot.reply_to(message, "scanner pong")

    @bot.message_handler(commands=["scan"])
    def scan(message):
        parts = message.text.split(maxsplit=1)
        ticker = parts[1].upper() if len(parts) > 1 else "THYAO"
        bot.reply_to(message, f"Scanner analiz hazir degil, altyapi aktif. Ticker: {ticker}")

    return bot
