import telebot

def build_bot(token):
    bot = telebot.TeleBot(token, threaded=False)

    @bot.message_handler(commands=["start", "help"])
    def start(message):
        bot.reply_to(message, "Prof Bot aktif. Komutlar: /ping /prof")

    @bot.message_handler(commands=["ping"])
    def ping(message):
        bot.reply_to(message, "prof pong")

    @bot.message_handler(commands=["prof"])
    def prof(message):
        bot.reply_to(message, "ProfBot altyapisi aktif, parametre test modulu sonraki adimda gelecek.")

    return bot
