import telebot

def build_bot(token):
    bot = telebot.TeleBot(token, threaded=False)

    @bot.message_handler(commands=["start", "help"])
    def start(message):
        bot.reply_to(message, "Strategy Bot aktif. Komutlar: /ping /tara")

    @bot.message_handler(commands=["ping"])
    def ping(message):
        bot.reply_to(message, "strategy pong")

    @bot.message_handler(commands=["tara"])
    def tara(message):
        bot.reply_to(message, "Tarama motoru altyapisi aktif, filtreler sonraki adimda gelecek.")

    return bot
