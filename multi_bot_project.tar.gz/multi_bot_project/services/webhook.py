import threading
import time
import requests
import telebot
from flask import request, abort
from core.config import Config

def attach_routes(app, bot_map):
    @app.route("/")
    def home():
        return {"status": "ok", "bots": list(bot_map.keys())}, 200

    @app.route("/health")
    def health():
        return "OK", 200

    for name, bot in bot_map.items():
        token = bot.token
        endpoint = f"/webhook/{name}/{token}"

        def make_handler(current_bot):
            def handler():
                if request.headers.get("content-type") == "application/json":
                    update = telebot.types.Update.de_json(request.get_data(as_text=True))
                    threading.Thread(target=current_bot.process_new_updates, args=([update],), daemon=True).start()
                    return "OK", 200
                abort(403)
            return handler

        app.add_url_rule(endpoint, f"webhook_{name}", make_handler(bot), methods=["POST"])

def set_all_webhooks(bot_map):
    if not Config.RENDERURL:
        print("RENDERURL eksik")
        return
    for name, bot in bot_map.items():
        try:
            bot.remove_webhook()
            time.sleep(1)
            url = f"{Config.RENDERURL}/webhook/{name}/{bot.token}"
            ok = bot.set_webhook(url=url)
            print(f"{name} webhook sonucu:", ok)
        except Exception as e:
            print(f"{name} webhook hata:", e)

def start_keepalive():
    if not Config.RENDERURL:
        return
    def loop():
        while True:
            try:
                requests.get(f"{Config.RENDERURL}/health", timeout=10)
            except Exception:
                pass
            time.sleep(840)
    threading.Thread(target=loop, daemon=True).start()
