from flask import Flask
from core.config import Config
from core.db import init_db
from services.webhook import attach_routes, set_all_webhooks, start_keepalive
from bots.scanner_bot import build_bot as build_scanner_bot
from bots.news_bot import build_bot as build_news_bot
from bots.strategy_bot import build_bot as build_strategy_bot
from bots.prof_bot import build_bot as build_prof_bot
from bots.ceo_bot import build_bot as build_ceo_bot

app = Flask(__name__)

bot_map = {}
if Config.SCANNER_BOT_TOKEN:
    bot_map["scanner"] = build_scanner_bot(Config.SCANNER_BOT_TOKEN)
if Config.NEWS_BOT_TOKEN:
    bot_map["news"] = build_news_bot(Config.NEWS_BOT_TOKEN)
if Config.STRATEGY_BOT_TOKEN:
    bot_map["strategy"] = build_strategy_bot(Config.STRATEGY_BOT_TOKEN)
if Config.PROF_BOT_TOKEN:
    bot_map["prof"] = build_prof_bot(Config.PROF_BOT_TOKEN)
if Config.CEO_BOT_TOKEN:
    bot_map["ceo"] = build_ceo_bot(Config.CEO_BOT_TOKEN)

attach_routes(app, bot_map)
init_db()
set_all_webhooks(bot_map)
start_keepalive()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=Config.PORT)
