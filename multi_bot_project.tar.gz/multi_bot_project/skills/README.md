Skill plan:
- scanner: support/resistance, risk, technical snapshot
- strategy: screening, sector filters, multi-timeframe score
- news: news ingestion, summarization, priority classification
- prof: parameter generation, backtest loop, proposal flow
- ceo: orchestration, summaries, approvals
