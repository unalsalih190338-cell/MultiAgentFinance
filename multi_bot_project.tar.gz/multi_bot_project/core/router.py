def active_bots(config):
    return {
        "ceo": bool(config.CEO_BOT_TOKEN),
        "news": bool(config.NEWS_BOT_TOKEN),
        "strategy": bool(config.STRATEGY_BOT_TOKEN),
        "scanner": bool(config.SCANNER_BOT_TOKEN),
        "prof": bool(config.PROF_BOT_TOKEN),
    }
