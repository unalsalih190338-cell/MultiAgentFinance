import os

class Config:
    PORT = int(os.getenv("PORT", "10000"))
    RENDERURL = (os.getenv("RENDERURL") or "").strip()
    DATABASEURL = (os.getenv("DATABASEURL") or "").strip()

    CEO_BOT_TOKEN = (os.getenv("CEO_BOT_TOKEN") or "").strip()
    NEWS_BOT_TOKEN = (os.getenv("NEWS_BOT_TOKEN") or "").strip()
    STRATEGY_BOT_TOKEN = (os.getenv("STRATEGY_BOT_TOKEN") or "").strip()
    SCANNER_BOT_TOKEN = (os.getenv("SCANNER_BOT_TOKEN") or "").strip()
    PROF_BOT_TOKEN = (os.getenv("PROF_BOT_TOKEN") or "").strip()
